#!/usr/bin/env python3
"""
CryptoVault — Caesar Cipher Tool with Hash Guard
=================================================
Stage 1: Caesar Lock   — encrypt, decrypt, and crack (frequency analysis)
Stage 2: Hash Guard    — SHA-256 integrity verification via --verify flag

Usage examples:
    python cryptovault.py encrypt message.txt --shift 7
    python cryptovault.py decrypt message.enc --shift 7
    python cryptovault.py encrypt message.txt --shift 7 --verify
    python cryptovault.py decrypt message.enc --shift 7 --verify
    python cryptovault.py crack --text "Wkh txlfn ..."
    python cryptovault.py crack ciphertext.txt
"""

import argparse
import hashlib
import string
import sys
import os

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HASH_SEPARATOR = "\n:::SHA256:::"

# English letter frequency table (source: standard corpus analysis)
# Used for scoring candidate plaintexts during frequency-analysis cracking.
ENGLISH_FREQ = {
    'a': 8.167, 'b': 1.492, 'c': 2.782, 'd': 4.253, 'e': 12.702,
    'f': 2.228, 'g': 2.015, 'h': 6.094, 'i': 6.966, 'j': 0.153,
    'k': 0.772, 'l': 4.025, 'm': 2.406, 'n': 6.749, 'o': 7.507,
    'p': 1.929, 'q': 0.095, 'r': 5.987, 's': 6.327, 't': 9.056,
    'u': 2.758, 'v': 0.978, 'w': 2.360, 'x': 0.150, 'y': 1.974,
    'z': 0.074,
}

# ---------------------------------------------------------------------------
# Core cipher functions
# ---------------------------------------------------------------------------

def caesar_encrypt(text: str, shift: int) -> str:
    """Encrypt *text* using a Caesar cipher with the given *shift*."""
    result = []
    for ch in text:
        if ch.isalpha():
            base = ord('A') if ch.isupper() else ord('a')
            result.append(chr((ord(ch) - base + shift) % 26 + base))
        else:
            result.append(ch)
    return "".join(result)


def caesar_decrypt(text: str, shift: int) -> str:
    """Decrypt is simply encrypting with the negative shift."""
    return caesar_encrypt(text, -shift)


# ---------------------------------------------------------------------------
# Frequency analysis / cracking
# ---------------------------------------------------------------------------

def score_text(text: str) -> float:
    """
    Score a candidate plaintext by comparing its letter-frequency
    distribution to standard English frequencies.

    Lower score = closer to English = more likely to be correct.
    We use chi-squared–style comparison.
    """
    text_lower = text.lower()
    letter_count = sum(1 for c in text_lower if c in string.ascii_lowercase)
    if letter_count == 0:
        return float('inf')

    score = 0.0
    for letter in string.ascii_lowercase:
        observed = text_lower.count(letter) / letter_count * 100
        expected = ENGLISH_FREQ.get(letter, 0)
        score += (observed - expected) ** 2 / (expected if expected else 0.01)
    return score


def crack_caesar(ciphertext: str, top_n: int = 3):
    """
    Try all 25 non-trivial shifts, score each candidate plaintext
    against English frequency, and return the *top_n* best results
    as a list of (shift, plaintext, score) tuples.
    """
    candidates = []
    for shift in range(1, 26):
        plaintext = caesar_decrypt(ciphertext, shift)
        candidates.append((shift, plaintext, score_text(plaintext)))
    # Sort by score ascending (lower = more English-like)
    candidates.sort(key=lambda x: x[2])
    return candidates[:top_n]


# ---------------------------------------------------------------------------
# Hash Guard helpers  (Stage 2)
# ---------------------------------------------------------------------------

def compute_sha256(text: str) -> str:
    """Return the hex SHA-256 digest of *text* (UTF-8 encoded)."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def encrypt_with_hash(plaintext: str, shift: int) -> str:
    """
    1. Compute SHA-256 hash of the original plaintext.
    2. Encrypt the plaintext.
    3. Append the hash after a separator so it travels with the ciphertext.
    """
    file_hash = compute_sha256(plaintext)
    ciphertext = caesar_encrypt(plaintext, shift)
    return f"{ciphertext}{HASH_SEPARATOR}{file_hash}"


def decrypt_with_hash(payload: str, shift: int) -> str:
    """
    1. Split ciphertext and stored hash.
    2. Decrypt the ciphertext.
    3. Recompute hash and compare — print result.
    4. Return the plaintext.
    """
    if HASH_SEPARATOR not in payload:
        print("[WARNING] --verify was used but no hash found in the file.")
        print("          Decrypting without integrity check.\n")
        return caesar_decrypt(payload, shift)

    ciphertext, stored_hash = payload.rsplit(HASH_SEPARATOR, 1)
    stored_hash = stored_hash.strip()
    plaintext = caesar_decrypt(ciphertext, shift)
    recomputed_hash = compute_sha256(plaintext)

    if recomputed_hash == stored_hash:
        print("\033[92m[✓ SUCCESS]\033[0m Integrity verified — SHA-256 hashes match.")
    else:
        print("\033[91m[✗ TAMPER WARNING]\033[0m Integrity check FAILED!")
        print(f"  Stored hash:     {stored_hash}")
        print(f"  Recomputed hash: {recomputed_hash}")
        print("  ⚠  The encrypted file may have been altered.\n")

    return plaintext


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="cryptovault",
        description="CryptoVault — Caesar cipher with optional SHA-256 Hash Guard",
    )
    sub = parser.add_subparsers(dest="command", help="Available commands")

    # -- encrypt --
    enc = sub.add_parser("encrypt", help="Encrypt a text file")
    enc.add_argument("filename", help="Path to the plaintext file")
    enc.add_argument("--shift", type=int, default=3,
                     help="Caesar shift value (default: 3)")
    enc.add_argument("--verify", action="store_true",
                     help="Embed SHA-256 hash for integrity verification")
    enc.add_argument("-o", "--output", default=None,
                     help="Output file (default: <filename>.enc)")

    # -- decrypt --
    dec = sub.add_parser("decrypt", help="Decrypt an encrypted file")
    dec.add_argument("filename", help="Path to the encrypted file")
    dec.add_argument("--shift", type=int, default=3,
                     help="Caesar shift value (default: 3)")
    dec.add_argument("--verify", action="store_true",
                     help="Verify SHA-256 hash after decryption")
    dec.add_argument("-o", "--output", default=None,
                     help="Output file (default: print to stdout)")

    # -- crack --
    crk = sub.add_parser("crack", help="Crack ciphertext via frequency analysis")
    crk.add_argument("filename", nargs="?", default=None,
                     help="File containing ciphertext (optional)")
    crk.add_argument("--text", type=str, default=None,
                     help="Ciphertext string to crack directly")
    crk.add_argument("-n", "--top", type=int, default=3,
                     help="Number of top candidates to show (default: 3)")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # ── ENCRYPT ──────────────────────────────────────────────────────────
    if args.command == "encrypt":
        try:
            with open(args.filename, "r", encoding="utf-8") as f:
                plaintext = f.read()
        except FileNotFoundError:
            print(f"Error: File '{args.filename}' not found.")
            sys.exit(1)

        if args.verify:
            output = encrypt_with_hash(plaintext, args.shift)
        else:
            output = caesar_encrypt(plaintext, args.shift)

        out_path = args.output or (args.filename + ".enc")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(output)

        print(f"Encrypted → {out_path}  (shift={args.shift}"
              f"{', hash-guard ON' if args.verify else ''})")

    # ── DECRYPT ──────────────────────────────────────────────────────────
    elif args.command == "decrypt":
        try:
            with open(args.filename, "r", encoding="utf-8") as f:
                payload = f.read()
        except FileNotFoundError:
            print(f"Error: File '{args.filename}' not found.")
            sys.exit(1)

        if args.verify:
            plaintext = decrypt_with_hash(payload, args.shift)
        else:
            # If there's a hash separator, strip it before decrypting
            if HASH_SEPARATOR in payload:
                payload = payload.split(HASH_SEPARATOR)[0]
            plaintext = caesar_decrypt(payload, args.shift)

        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(plaintext)
            print(f"Decrypted → {args.output}")
        else:
            print("\n--- Decrypted plaintext ---")
            print(plaintext)

    # ── CRACK ────────────────────────────────────────────────────────────
    elif args.command == "crack":
        if args.text:
            ciphertext = args.text
        elif args.filename:
            try:
                with open(args.filename, "r", encoding="utf-8") as f:
                    ciphertext = f.read()
            except FileNotFoundError:
                print(f"Error: File '{args.filename}' not found.")
                sys.exit(1)
        else:
            print("Error: Provide either --text or a filename.")
            sys.exit(1)

        print(f"Cracking ciphertext ({len(ciphertext)} chars) …\n")
        results = crack_caesar(ciphertext, args.top)
        for rank, (shift, plaintext, score) in enumerate(results, 1):
            print(f"#{rank}  [shift={shift:2d}]  score={score:.2f}")
            print(f"    {plaintext}\n")


if __name__ == "__main__":
    main()