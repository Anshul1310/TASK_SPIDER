# CryptoVault — Write-Up

**Name:** Anshul Negi  
**Roll No:** _[Your Roll Number]_  
**Date:** June 2026

---

## Overview

CryptoVault is a command-line cryptographic tool built in Python that demonstrates two foundational security concepts:

1. **Stage 1 — Caesar Lock:** Classical substitution cipher with a brute-force / frequency-analysis cracker.
2. **Stage 2 — Hash Guard:** SHA-256 integrity verification layered on top of encryption.

---

## Stage 1: Caesar Lock

### What It Implements

The Caesar cipher is a **monoalphabetic substitution cipher** — one of the oldest known encryption schemes, attributed to Julius Caesar. Each letter in the plaintext is replaced by a letter a fixed number of positions down the alphabet.

| Operation | Formula |
|-----------|---------|
| Encrypt   | `E(x) = (x + k) mod 26` |
| Decrypt   | `D(x) = (x − k) mod 26` |

where `x` is the letter index (A=0 … Z=25) and `k` is the shift key.

**CLI usage:**

```bash
# Encrypt with shift of 7
python cryptovault.py encrypt message.txt --shift 7

# Decrypt
python cryptovault.py decrypt message.txt.enc --shift 7

# Crack ciphertext (top 3 candidates via frequency analysis)
python cryptovault.py crack --text "Wkh txlfn eurzq ira mxpsv ..."
```

### What It Protects Against

Caesar provides **basic confidentiality** — a casual reader cannot immediately understand the ciphertext. Historically it was used when the adversary was illiterate or lacked the time to decode the message.

### Why Caesar Is Trivially Breakable

1. **Tiny key space.** There are only **25 possible shifts** (shift 0 returns the original). An attacker can simply try all 25 and visually inspect the output — a brute-force attack finishes in microseconds on any modern machine.

2. **No key complexity.** The "key" is a single integer. There is no mixing, no diffusion, no confusion (to use Claude Shannon's terminology). The transformation is fully predictable once the key is known.

3. **Structure preservation.** Word boundaries, punctuation, spacing, and letter case are all preserved. This leaks an enormous amount of information about the plaintext's structure.

### How Frequency Analysis Works

Every natural language has a **characteristic letter-frequency distribution**. In English:

- **'e'** is the most common letter (~12.7%)
- **'t', 'a', 'o', 'i', 'n', 's', 'h', 'r'** follow in roughly that order
- **'z', 'q', 'x', 'j'** are the rarest (~0.07–0.15%)

Because a Caesar cipher shifts **every letter by the same amount**, the frequency distribution of the ciphertext is simply the English distribution shifted by *k* positions. My cracker:

1. Decrypts the ciphertext with each of the 25 possible shifts.
2. Computes the letter-frequency distribution of each candidate plaintext.
3. Compares it to the known English distribution using a **chi-squared score**.
4. Ranks candidates — the lowest score is the most "English-like."

**The key property that makes frequency analysis work** is that natural language is **not uniformly distributed**. Letters, bigrams, and words follow predictable statistical patterns. Any cipher that preserves this underlying distribution (like simple substitution) can be attacked statistically.

### Cracking Result

Given ciphertext:
> "Wkh txlfn eurzq ira mxpsv ryhu wkh odcb grj. Fubswrjudskb lv wkh duw ri zulwlqj dqg vroylqj frghv."

| Rank | Shift | Plaintext |
|------|-------|-----------|
| #1   | 3     | The quick brown fox jumps over the lazy dog. Cryptography is the art of writing and solving codes. |
| #2   | 16    | Gur dhvpx oebja sbk whzcf bire gur ynml qbt. Pelcgbtencul vf gur neg bs jevgvat naq fbyivat pbqrf. |
| #3   | 15    | Hvs eiwqy pfckb tcl xiadg cjsf hvs zonm rcu. Qfmdhcufodvm wg hvs ofh ct kfwhwbu obr gczjwbu qcrsg. |

The correct key is **shift = 3**, identified with highest confidence (lowest chi-squared score of 69.39).

### Limitations

- Only works on alphabetic characters; digits and symbols pass through unchanged.
- Provides **zero real-world security** — any automated tool breaks it instantly.
- Vulnerable to **known-plaintext attacks**, **brute force**, and **frequency analysis**.
- Cannot handle multi-language text well (frequency tables are language-specific).

---

## Stage 2: Hash Guard

### What It Implements

Hash Guard adds **integrity verification** to the encryption pipeline using **SHA-256**, a cryptographic hash function from the SHA-2 family.

**How it works:**

```
ENCRYPT (with --verify):
  1. Read plaintext from file
  2. Compute SHA-256(plaintext) → 64-character hex digest
  3. Encrypt plaintext with Caesar cipher
  4. Write: ciphertext + ":::SHA256:::" + hash → .enc file

DECRYPT (with --verify):
  1. Read .enc file, split at ":::SHA256:::"
  2. Decrypt the ciphertext portion
  3. Compute SHA-256(decrypted_plaintext)
  4. Compare with stored hash
     → Match:    print SUCCESS
     → Mismatch: print TAMPER WARNING
```

### What It Protects Against

| Threat | Without Hash Guard | With Hash Guard |
|--------|-------------------|-----------------|
| Eavesdropping | Cipher provides basic (weak) confidentiality | Same |
| Tampering | Undetected — attacker can modify .enc file silently | **Detected** — hash mismatch triggers warning |
| Corruption | Undetected — bit flips or truncation go unnoticed | **Detected** — any change to the file changes the hash |

### Why You Need Both Encryption AND Hashing

**Encryption provides confidentiality** — it ensures that an unauthorized party cannot *read* the message. However, encryption alone says nothing about whether the message was *modified* in transit.

**Hashing provides integrity** — it ensures that the message has not been *altered*. However, a hash alone says nothing about whether the message is *secret*.

Consider these attack scenarios:

1. **Encryption without integrity:** An attacker intercepts the encrypted file and flips some bytes. The recipient decrypts it and gets garbage — but they have no way to know the output is wrong. In a protocol context, this can be catastrophic (e.g., changing an encrypted bank transfer amount).

2. **Integrity without encryption:** An attacker can read the message freely. The hash only tells the recipient "yes, this is exactly the message the attacker wanted you to see" — which is useless if confidentiality is needed.

**You need both** to achieve a meaningful security guarantee: the message is **secret** (confidentiality) AND **unaltered** (integrity).

> In real-world cryptography, this is typically achieved with **Authenticated Encryption with Associated Data (AEAD)** schemes like AES-GCM, which provide both properties in a single operation.

### SHA-256 Properties

| Property | Meaning |
|----------|---------|
| **Deterministic** | Same input always produces the same 256-bit hash |
| **Pre-image resistant** | Given a hash, it's computationally infeasible to find the original input |
| **Collision resistant** | It's computationally infeasible to find two different inputs with the same hash |
| **Avalanche effect** | A single-bit change in input produces a radically different hash |

The avalanche effect is what makes Hash Guard effective — even a tiny modification to the `.enc` file (changing one letter) produces a completely different SHA-256 digest, making tampering immediately detectable.

### Test: Tampering Detection

```bash
# Encrypt with hash guard
$ python cryptovault.py encrypt message.txt --shift 7 --verify
Encrypted → message.txt.enc  (shift=7, hash-guard ON)

# Decrypt normally — hashes match
$ python cryptovault.py decrypt message.txt.enc --shift 7 --verify
[✓ SUCCESS] Integrity verified — SHA-256 hashes match.

# Corrupt the file (change some ciphertext bytes)
$ sed -i 's/xbpjr/XXXXX/' message.txt.enc

# Decrypt again — tamper detected!
$ python cryptovault.py decrypt message.txt.enc --shift 7 --verify
[✗ TAMPER WARNING] Integrity check FAILED!
  Stored hash:     5f2b39246627e07c47674876543344584d4fff3e...
  Recomputed hash: 825f7982c998d39f5115674a2cce876482e51...
  ⚠  The encrypted file may have been altered.
```

### Limitations

- **Hash is stored in plaintext** alongside the ciphertext. An attacker who modifies the ciphertext could also recompute and replace the hash (since Caesar is trivially breakable). In real systems, you'd use an **HMAC** (keyed hash) or a **digital signature** to prevent this.
- **Caesar cipher is fundamentally insecure** — Hash Guard improves integrity but the overall system remains trivially breakable.
- **No authentication** — we can detect tampering, but we cannot verify *who* sent the message.
- **The hash is of the plaintext, not the ciphertext.** In a more rigorous design (Encrypt-then-MAC), you would hash the ciphertext to prevent oracle attacks.

---

## Conclusion

CryptoVault demonstrates the layered nature of security:

| Layer | Mechanism | Property | Limitation |
|-------|-----------|----------|------------|
| Stage 1 | Caesar cipher | Confidentiality (weak) | Key space of only 25; broken by brute force or frequency analysis |
| Stage 2 | SHA-256 hash | Integrity | Hash is unkeyed and stored in plaintext; an attacker could replace it |

Real-world systems address these limitations with:
- **Modern ciphers** (AES-256) for strong confidentiality
- **HMAC or digital signatures** for authenticated integrity
- **Key exchange protocols** (Diffie-Hellman, RSA) for secure key distribution
- **AEAD modes** (AES-GCM, ChaCha20-Poly1305) that combine encryption and authentication in a single pass

The value of this exercise is understanding *why* each layer exists and *what* it protects against — the conceptual foundation that modern cryptographic protocols are built upon.
